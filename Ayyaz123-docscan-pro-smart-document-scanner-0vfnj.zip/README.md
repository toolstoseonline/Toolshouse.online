---
title: DocScan Pro - Smart Document Scanner 📄
colorFrom: yellow
colorTo: green
sdk: static
emoji: 🧩
tags:
  - deepsite-v4
---

# DocScan Pro - Smart Document Scanner 📄

This project has been created with [DeepSite](https://deepsite.hf.co) AI Vibe Coding.
