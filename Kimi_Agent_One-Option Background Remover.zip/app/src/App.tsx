import { useState, useRef, useCallback } from 'react';
import { Upload, Download, Trash2, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';
import * as bgRemoval from '@imgly/background-removal';

function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Please select an image file');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setOriginalImage(e.target?.result as string);
        setProcessedImage(null);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setOriginalImage(event.target?.result as string);
        setProcessedImage(null);
      };
      reader.readAsDataURL(file);
    } else {
      toast.error('Please drop an image file');
    }
  }, []);

  const removeBg = async () => {
    if (!originalImage) return;
    
    setIsProcessing(true);
    try {
      // Convert base64 to blob
      const response = await fetch(originalImage);
      const blob = await response.blob();
      
      // Remove background using imgly
      const resultBlob = await bgRemoval.removeBackground(blob);
      
      const resultUrl = URL.createObjectURL(resultBlob);
      setProcessedImage(resultUrl);
      toast.success('Background removed successfully!');
    } catch (error) {
      toast.error('Failed to remove background. Please try again.');
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (processedImage) {
      const link = document.createElement('a');
      link.href = processedImage;
      link.download = 'removed-background.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Image downloaded!');
    }
  };

  const handleClear = () => {
    setOriginalImage(null);
    setProcessedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col items-center justify-center p-4">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
          Background Remover
        </h1>
        <p className="text-gray-300 text-lg">
          Remove image backgrounds instantly - 100% free
        </p>
      </div>

      {/* Main Card */}
      <Card className="w-full max-w-4xl bg-white/10 backdrop-blur-lg border-white/20 p-6 md:p-8">
        {!originalImage ? (
          /* Upload Area */
          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-white/30 rounded-2xl p-12 text-center cursor-pointer hover:border-white/60 hover:bg-white/5 transition-all duration-300"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <Upload className="w-10 h-10 text-white" />
              </div>
              <div>
                <p className="text-white text-xl font-semibold mb-1">
                  Click or drag image here
                </p>
                <p className="text-gray-400 text-sm">
                  Supports JPG, PNG, WEBP (max 10MB)
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Image Preview Area */
          <div className="space-y-6">
            {/* Image Comparison */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Original */}
              <div className="space-y-2">
                <p className="text-white/70 text-sm font-medium flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  Original
                </p>
                <div className="bg-gray-800/50 rounded-xl overflow-hidden aspect-square flex items-center justify-center">
                  <img
                    src={originalImage}
                    alt="Original"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              </div>

              {/* Result */}
              <div className="space-y-2">
                <p className="text-white/70 text-sm font-medium flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  Result
                </p>
                <div 
                  className="rounded-xl overflow-hidden aspect-square flex items-center justify-center"
                  style={{
                    backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                  }}
                >
                  {processedImage ? (
                    <img
                      src={processedImage}
                      alt="Result"
                      className="max-w-full max-h-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full bg-gray-800/80 w-full">
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-10 h-10 text-purple-400 animate-spin mb-2" />
                          <p className="text-white/70 text-sm">Removing background...</p>
                        </>
                      ) : (
                        <>
                          <ImageIcon className="w-10 h-10 text-gray-500 mb-2" />
                          <p className="text-gray-500 text-sm">Result will appear here</p>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 justify-center">
              {!processedImage && !isProcessing && (
                <Button
                  onClick={removeBg}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-6 text-lg font-semibold"
                >
                  <ImageIcon className="w-5 h-5 mr-2" />
                  Remove Background
                </Button>
              )}
              
              {processedImage && (
                <Button
                  onClick={handleDownload}
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg font-semibold"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Download Result
                </Button>
              )}
              
              <Button
                onClick={handleClear}
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-6 py-6"
              >
                <Trash2 className="w-5 h-5 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* Footer */}
      <p className="text-gray-400 text-sm mt-8">
        All processing happens in your browser - your images are never uploaded to any server
      </p>
    </div>
  );
}

export default App;
